# MAX7219 8x8 Dot Matrix Display
Available functions:
1. Init(): initializes MAX7219 & sets brightness level (0 to 15)
2. Clear(): clears display by turning OFF all LEDs
3. Number(): displays number between 0 and 9
4. Letter(): display alphabet (small or capital)
5. Byte(): displays 8-bit binary on selected row position
